# CRIO_SOLUTION_AND_STUB_START_MODULE_L1
# CRIO_SOLUTION_AND_STUB_END_MODULE_L1
python3 assesment/assess.py build/reports/checkstyle/test.xml build/chromedriver.log build/reports/tests/test/testng-results.xml assesment/INSTRUCTIONS.json